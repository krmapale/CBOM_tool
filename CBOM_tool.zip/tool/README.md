# CycloneDX_PQC

Tool for creating PQC focused CBOM.


## Help
```text
$ pqcbom -h

Usage: 
    
    pqcbom [OPTION] [SCAN DIRECTORY]

Options:

    -i, --input                     Input type. Default file directory.
        --git                       Git directory as input.
        --docker                    Docker container as input.
    -h, --help                      Show help
    -v, --version                   Show version number

```